@echo off
powershell -ExecutionPolicy Bypass ./ESget.ps1
echo %errorlevel%
pause
