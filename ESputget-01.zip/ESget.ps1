$FilePath = $Args[0]
$OutputPath = $FilePath

$Uri  = "http://eseram.local:8080/fat/files"
$Uri1 = "http://eseram.local:8080/fat/status"
$Uri2 = $Uri + "/" + $Args[0]

try {
    if ($Args[0] -eq $null) {
        Write-Host "Connecting to $Uri1 ..."
        $Response = Invoke-RestMethod -Uri $Uri1 -Method Get
        $Response
        Write-Host "Connecting to $Uri ..."
        $Response = Invoke-RestMethod -Uri $Uri -Method Get
        $Response | Format-Table -AutoSize
    } else {
        Write-Host "Connecting to $Uri ..."
        Write-Host "Downloading $FilePath ..."
        $Response = Invoke-RestMethod -Uri $Uri2 -Method Get -OutFile $OutputPath
        Write-Host "Success: $Response" -ForegroundColor Green
    }
} catch {
    Write-Error "Download failed: $_"
}

