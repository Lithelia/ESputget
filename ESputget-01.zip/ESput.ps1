# �t�@�C���`�F�b�N
$FilePath = Resolve-Path $Args[0]
$FileUpdate = (Get-ItemProperty $FilePath).LastWriteTime | Get-Date -Format "yyyy/MM/dd HH:mm:ss" 

if (-not (Test-Path $FilePath)) {
    Write-Error "�w�肳�ꂽ�t�@�C����������܂���: $FilePath"
    exit
}

$Uri = "http://eseram.local:8080/fat/files/" + $Args[0] + "?mtime=$FileUpdate"

$FileBytes = [System.IO.File]::ReadAllBytes($FilePath)

Write-Host "Connecting to $Uri ..."
Write-Host "Uploading $FilePath ($FileUpdate)..."

try {
    $Response = Invoke-RestMethod -Uri $Uri -Method Post -InFile $FilePath -ContentType "application/octet-stream"
    Write-Host "Success: $Response" -ForegroundColor Green
} catch {
    Write-Error "Upload failed: $_"
}
