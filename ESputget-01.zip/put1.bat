@echo off
powershell -ExecutionPolicy Bypass ./ESput.ps1 SF.COM
echo ERRORLEVEL : %errorlevel%
pause
