@echo off
powershell -ExecutionPolicy Bypass ./ESget.ps1 SF.COM
echo ERRORLEVEL : %errorlevel%
pause
