@echo off
powershell -ExecutionPolicy Bypass ./ESput.ps1 disk image.dsk
echo ERRORLEVEL : %errorlevel%
pause
