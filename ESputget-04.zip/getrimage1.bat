@echo off
powershell -ExecutionPolicy Bypass ./ESget.ps1 image fatimage.bin
echo ERRORLEVEL : %errorlevel%
pause
