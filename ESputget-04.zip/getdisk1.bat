@echo off
rem powershell -ExecutionPolicy Bypass ./ESget.ps1 disk image.dsk
powershell -ExecutionPolicy Bypass ./ESget.ps1 disk D:\WORK\MSX\UPDOWN\image.dsk
echo ERRORLEVEL : %errorlevel%
pause
