param (
    [string]$type,
    [string]$FilePath,
    [string]$DownDir
)

$Uri  = "http://eseram.local:8080/"

if ($type -eq "dir") {
    $Uri1 = $Uri + "fat/status"
    $Uri2 = $Uri + "fat/files"
    if (($FilePath -ne $Null) -and ($FilePath -ne "")) {
        # �擪�ƍŌ��/��\���g����
        $UriPath = $FilePath.Trim('/')
        $UriPath = $UriPath.Trim('\')
        $Uri2 = $Uri2 + "?path=$UriPath"
    }
    Write-Host "Directory List: [$UriPath]"
} else {
    if (($FilePath -eq $Null) -or ($FilePath -eq "")) {
        Write-Error "Parameter error"
        exit 2
    }

    if ($type -eq "file") {
        # �擪�ƍŌ��/��\���g����
        $UriPath = $FilePath.Trim('/')
        $UriPath = $UriPath.Trim('\')

        $Uri4 = $Uri  + "fat/files/$UriPath"
        $Uri3 = $Uri4 + "?stat=true"

        $file = Split-Path  $FilePath -Leaf
        $FilePath = $file

        if (($DownDir -ne $Null) -and ($DownDir -ne "")) {
            # �擪�ƍŌ��/��\���g����
            $DownPath = $DownDir.Trim('/')
            $DownPath = $DownPath.Trim('\')

            # �t�H���_�`�F�b�N
            if (-not (Test-Path $DownPath)) {
                Write-Error "Directory not found: $DownPath"
                exit 2
            }

            $FilePath = $DownPath + "\$file"
            $FilePath = $FilePath.Trim('\')
        }
    } elseif ($type -eq "rom") {
        $Uri3 = $Uri + "ram"
    } elseif ($type -eq "disk") {
        $Uri3 = $Uri + "ram?start=0x20000&size=737280"
    } elseif ($type -eq "image") {
        $Uri3 = $Uri + "ram?start=0x20000"
    } else {
        Write-Error "Parameter error: $type"
        exit 2
    }
    Write-Host "Download File: [$FilePath]"
}

try {
    if ($type -eq "dir") {
        # status
        Write-Host "Connecting to $Uri1 ..." -NoNewline
        $Response = Invoke-RestMethod -Uri $Uri1 -Method Get
        $Response
        $Free  = $Response.free_size
        $Total = $Response.total_size

        # dir
        Write-Host "Connecting to $Uri2 ..." -NoNewline
        $Response = Invoke-RestMethod -Uri $Uri2 -Method Get
        $Response | Format-Table -AutoSize
        Write-Host $Response.Count "Files" ($Free / 1024) "KB Free / Total" ($Total / 1024) "KB`n"
    } else {
        Write-Host "Connecting to $Uri3 ..."
        Write-Host "Downloading $UriPath ..."
        $Response = Invoke-WebRequest -Uri $Uri3 -Method Get -UseBasicParsing -PassThru -OutFile $FilePath
        if (($Response -ne $null) -and ($type -eq "file") -and `
            ($Response.Headers['Content-Type'] -eq "application/json")) {
                # �_�E�����[�h�ƃ^�C���X�^���v�t�^
                $json = $Response.Content | ConvertFrom-Json
                $FileUpdate = $json.date
                Write-Host "Success Get File Timestamp" -ForegroundColor Green
                Write-Host "Update time  = $FileUpdate"
                $Response = Invoke-RestMethod -Uri $Uri4 -Method Get -OutFile $FilePath
                Set-ItemProperty -Path $FilePath -Name LastWriteTime -Value (Get-Date $FileUpdate)
        }
        Write-Host "Success File Download" -ForegroundColor Green
    }
} catch {
    Write-Error "Download failed: $_"
    exit 1
}
