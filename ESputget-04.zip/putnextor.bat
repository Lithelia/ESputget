@echo off
powershell -ExecutionPolicy Bypass ./ESput.ps1 nextor nextor-eseramair.rom
echo ERRORLEVEL : %errorlevel%
pause
