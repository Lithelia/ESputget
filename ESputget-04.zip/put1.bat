@echo off
powershell -ExecutionPolicy Bypass ./ESput.ps1 file SF.COM
rem powershell -ExecutionPolicy Bypass ./ESput.ps1 file D:\WORK\MSX\UPDOWN\SF.COM /UTY
echo ERRORLEVEL : %errorlevel%
pause
