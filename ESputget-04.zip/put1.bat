@echo off
rem powershell -ExecutionPolicy Bypass ./ESput.ps1 file SF.COM
powershell -ExecutionPolicy Bypass ./ESput.ps1 file D:\WORK\MSX\UPDOWN\SF.COM /UTY
echo ERRORLEVEL : %errorlevel%
pause
