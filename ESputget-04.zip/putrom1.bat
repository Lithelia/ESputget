@echo off
powershell -ExecutionPolicy Bypass ./ESput.ps1 rom IMAGE.ROM
echo ERRORLEVEL : %errorlevel%
pause
