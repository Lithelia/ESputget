@echo off
powershell -ExecutionPolicy Bypass ./ESput.ps1 image fatimage.bin
echo ERRORLEVEL : %errorlevel%
pause
