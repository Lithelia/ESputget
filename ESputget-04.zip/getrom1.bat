@echo off
powershell -ExecutionPolicy Bypass ./ESget.ps1 rom IMAGE.ROM
echo ERRORLEVEL : %errorlevel%
pause
