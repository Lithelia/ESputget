@echo off
powershell -ExecutionPolicy Bypass ./ESetc.ps1 del ABC
echo ERRORLEVEL : %errorlevel%
pause
