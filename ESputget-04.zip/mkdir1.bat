@echo off
powershell -ExecutionPolicy Bypass ./ESetc.ps1 mkdir ABC
echo ERRORLEVEL : %errorlevel%
pause
