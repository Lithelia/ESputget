param (
    [string]$type,
    [string]$file,
    [string]$rename
)

$Uri  = "http://eseram.local:8080/"
$Uri1 = $Uri + "fat/files/$file"
$Uri2 = $Uri + "fat/directories/$file"
$Uri3 = $Uri + "fat/rename?src=$file&dst=$rename"

if ($type -eq "del") {
    Write-Host "Connecting to $Uri1 ..."
    Write-Host "Deleting $file ..."

    try {
        $Response = Invoke-RestMethod -Uri $Uri1 -Method Delete
        Write-Host "Success delete" -ForegroundColor Green
    } catch {
        $_.Exception.Response.StatusCode.value__
        Write-Error "Delete failed: $_"
        exit 1
    }
} elseif ($type -eq "mkdir") {
    Write-Host "Connecting to $Uri2 ..."
    Write-Host "Making directory $file ..."

    try {
        $Response = Invoke-RestMethod -Uri $Uri2 -Method Post
        Write-Host "Success make directory" -ForegroundColor Green
    } catch {
      #  $HttpCode    = $_.Exception.Response.StatusCode
      #  $HttpCodeVal = $HttpCode.value__
      #  Write-Host "HttpCode = $HttpCodeVal ($HttpCode)"
        Write-Error "Make directory failed: $_"
        exit 1
    }
} elseif ($type -eq "ren") {
    Write-Host "Connecting to $Uri3 ..."
    Write-Host "Rename $file to $rename ..."

    try {
        $Response = Invoke-RestMethod -Uri $Uri3 -Method Post
        Write-Host "Success make directory" -ForegroundColor Green
    } catch {
      #  $HttpCode    = $_.Exception.Response.StatusCode
      #  $HttpCodeVal = $HttpCode.value__
      #  Write-Host "HttpCode = $HttpCodeVal ($HttpCode)"
        Write-Error "Rename failed: $_"
        exit 1
    }


}
