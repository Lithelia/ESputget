@echo off
powershell -ExecutionPolicy Bypass ./ESget.ps1 file SF.COM
rem powershell -ExecutionPolicy Bypass ./ESget.ps1 file /UTY/SF.COM D:\WORK\MSX\UPDOWN\
echo ERRORLEVEL : %errorlevel%
pause
