@echo off
rem powershell -ExecutionPolicy Bypass ./ESget.ps1 file SF.COM
powershell -ExecutionPolicy Bypass ./ESget.ps1 file /UTY/SF.COM D:\WORK\MSX\UPDOWN\
echo ERRORLEVEL : %errorlevel%
pause
