@echo off
powershell -ExecutionPolicy Bypass ./ESetc.ps1 ren ABC XXX
echo ERRORLEVEL : %errorlevel%
pause
