@echo off
rem powershell -ExecutionPolicy Bypass ./ESget.ps1 dir
powershell -ExecutionPolicy Bypass ./ESget.ps1 dir /UTY/ABC/
echo ERRORLEVEL : %errorlevel%
pause
