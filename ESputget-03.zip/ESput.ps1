param (
    [string]$type,
    [string]$file
)

# �t�@�C���`�F�b�N
$FilePath = Resolve-Path $file

if (-not (Test-Path $FilePath)) {
    Write-Error "File not found: $FilePath"
    exit 2
}

$FileUpdate = (Get-ItemProperty $FilePath).LastWriteTime | Get-Date -Format "yyyy/MM/dd HH:mm:ss" 

$Uri = "http://eseram.local:8080/"

if ($type -eq "file") {
    $Uri1 = $Uri + "fat/files/" + $file + "?mtime=$FileUpdate"
} elseif ($type -eq "rom") {
    $Uri1 = $Uri + "ram"
} elseif ($type -eq "nextor") {
    $Uri1 = $Uri + "ram"
    $Uri2 = $Uri + "fat/format"
} elseif (($type -eq "disk") -or ($type -eq "image")) {
    $Uri1 = $Uri + "ram?start=0x20000"
} else {
    Write-Error "Parameter error: $type"
    exit 2
}

$FileBytes = [System.IO.File]::ReadAllBytes($FilePath)

Write-Host "Connecting to $Uri ..."
Write-Host "Uploading $FilePath ($FileUpdate)..."

# For read-only file, Copy and False IsReadOnly
$CopyFile = "##temp.tmp"
Copy-Item -Path $FilePath -Destination $CopyFile
Set-ItemProperty -Path $CopyFile -Name IsReadOnly -Value $False

try {
    $Response = Invoke-RestMethod -Uri $Uri1 -Method Post -InFile $CopyFile -ContentType "application/octet-stream"
    Remove-Item -Path $CopyFile
    $Response | Format-Table -AutoSize
    Write-Host "Success upload" -ForegroundColor Green
} catch {
    Write-Error "Upload failed: $_"
    Remove-Item -Path $CopyFile
    exit 1
}

if ($type -eq "nextor") {
    Write-Host "Connecting to $Uri2 ..."
    Write-Host "Formatting ..."

    try {
        $Response = Invoke-RestMethod -Uri $Uri2 -Method Post
        Write-Host $Response
        Write-Host "Success format" -ForegroundColor Green
    } catch {
        Write-Error "Format failed: $_"
        exit 1
    }
}

