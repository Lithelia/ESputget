@echo off
powershell -ExecutionPolicy Bypass ./ESget.ps1 file
echo ERRORLEVEL : %errorlevel%
pause
