@echo off
powershell -ExecutionPolicy Bypass ./ESput.ps1 file SF.COM
echo ERRORLEVEL : %errorlevel%
pause
