param (
    [string]$type,
    [string]$FilePath
)

$Uri  = "http://eseram.local:8080/"

if ($type -eq "file") {
    $Uri1 = $Uri + "fat/status"
    $Uri2 = $Uri + "fat/files"
    $Uri3 = $Uri2 + "/" + $FilePath + "?stat=true"
    $Uri4 = $Uri2 + "/" + $FilePath
} elseif ($type -eq "rom") {
    $Uri3 = $Uri + "ram"
} elseif ($type -eq "disk") {
    $Uri3 = $Uri + "ram?start=0x20000&size=737280"
} elseif ($type -eq "image") {
    $Uri3 = $Uri + "ram?start=0x20000"
} else {
    Write-Error "Parameter error: $type"
    exit 2
}

#try {
    if ($FilePath -eq "") {
        # status
        Write-Host "Connecting to $Uri1 ..." -NoNewline
        $Response = Invoke-RestMethod -Uri $Uri1 -Method Get
        $Response
        $Free  = $Response.free_size
        $Total = $Response.total_size

        # dir
        Write-Host "Connecting to $Uri2 ..." -NoNewline
        $Response = Invoke-RestMethod -Uri $Uri2 -Method Get
        $Response | Format-Table -AutoSize
        Write-Host $Response.Count "Files" ($Free / 1024) "KB Free / Total" ($Total / 1024) "KB`n"
    } else {
        Write-Host "Connecting to $Uri3 ..."
        Write-Host "Downloading $FilePath ..."
        $Response = Invoke-WebRequest -Uri $Uri3 -Method Get -UseBasicParsing -PassThru -OutFile $FilePath
        if (($Response -ne $null) -and ($type -eq "file") -and `
            ($Response.Headers['Content-Type'] -eq "application/json")) {
                $json = $Response.Content | ConvertFrom-Json
                $FileUpdate = $json.date
                Write-Host "Success Get File Timestamp" -ForegroundColor Green
                Write-Host "Update time  = $FileUpdate"
                $Response = Invoke-RestMethod -Uri $Uri4 -Method Get -OutFile $FilePath
                Set-ItemProperty -Path $FilePath -Name LastWriteTime -Value (Get-Date $FileUpdate)
        }
        Write-Host "Success File Download" -ForegroundColor Green
    }
#} catch {
#    Write-Error "Download failed: $_"
#    exit 1
#}
