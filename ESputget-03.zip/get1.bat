@echo off
powershell -ExecutionPolicy Bypass ./ESget.ps1 file SF.COM
echo ERRORLEVEL : %errorlevel%
pause
