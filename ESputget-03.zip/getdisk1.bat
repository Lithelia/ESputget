@echo off
powershell -ExecutionPolicy Bypass ./ESget.ps1 disk image.dsk
echo ERRORLEVEL : %errorlevel%
pause
