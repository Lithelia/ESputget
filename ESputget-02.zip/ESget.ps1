param (
    [string]$type,
    [string]$FilePath
)

$Uri  = "http://eseram.local:8080/"

if ($type -eq "file") {
    $Uri1 = $Uri + "fat/status"
    $Uri2 = $Uri + "fat/files"
    $Uri3 = $Uri2 + "/" + $FilePath
} elseif ($type -eq "rom") {
    $Uri2 = $Uri + "ram"
    $Uri3 = $Uri2
} elseif ($type -eq "disk") {
    $Uri2 = $Uri + "ram?start=0x20000&size=737280"
    $Uri3 = $Uri2
} elseif ($type -eq "image") {
    $Uri2 = $Uri + "ram?start=0x20000"
    $Uri3 = $Uri2
} else {
    Write-Error "Parameter error: $type"
    exit 2
}

try {
    if ($FilePath -eq "") {
        # status
        Write-Host "Connecting to $Uri1 ..."
        $Response = Invoke-RestMethod -Uri $Uri1 -Method Get
        $Response

        # dir
        Write-Host "Connecting to $Uri2 ..."
        $Response = Invoke-RestMethod -Uri $Uri2 -Method Get
        $Response | Format-Table -AutoSize
    } else {
        Write-Host "Connecting to $Uri2 ..."
        Write-Host "Downloading $FilePath ..."
        $Response = Invoke-RestMethod -Uri $Uri3 -Method Get -OutFile $FilePath
        Write-Host "Success: $Response" -ForegroundColor Green
    }
} catch {
    Write-Error "Download failed: $_"
    exit 1
}

